﻿Imports Telerik.WinControls
Imports Telerik.WinControls.UI
Imports System.ComponentModel
Imports System.Data.SqlClient

Public Class FrmCarStock

    Dim srNo As Integer
    Dim brand_Model As String
    Dim mfgYear As Integer
    Dim quantity As Integer

    Dim connection As New SqlConnection("Data Source=CHINMAY;Initial Catalog=DB_CarStock;User ID=sa;Password=vspl@123")

    Private Sub FrmCarStock_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.txtMfg_Year.Format = DateTimePickerFormat.[Custom]
            Me.txtMfg_Year.CustomFormat = "yyyy"

            LoadGridData()
        Catch ex As Exception
            RadMessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            If fnValidate() = False Then
                Exit Sub
            End If

            srNo = Convert.ToInt32(txtSr_No.Text)
            brand_Model = Convert.ToString(txtBrand_Model.Text)
            mfgYear = Convert.ToInt32(txtMfg_Year.Text)
            quantity = Convert.ToInt32(txtQuantity.Text)

            Dim insertQuery As String = "INSERT INTO tbl_CarStockDetails (Sr_No, Brand_Model, Mfg_Year, Quantity) VALUES('" & srNo & "','" & brand_Model & "'," & mfgYear & ",'" & quantity & "')"
            If (checkAlreadyExist() = True) Then
                RadMessageBox.Show("Record Already Exists", "", MessageBoxButtons.OK, RadMessageIcon.Info)
            Else
                ExecuteQuery(insertQuery)
                LoadGridData()
                RadMessageBox.Show("Record saved successfully ", "Success", MessageBoxButtons.OK, RadMessageIcon.Info)
            End If          
        Catch ex As Exception
            RadMessageBox.Show(ex.Message)
            Me.Dispose()
        End Try
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Try
            If fnValidate() = False Then
                Exit Sub
            End If

            srNo = Convert.ToInt32(txtSr_No.Text)
            brand_Model = Convert.ToString(txtBrand_Model.Text)
            mfgYear = Convert.ToInt32(txtMfg_Year.Text)
            quantity = Convert.ToInt32(txtQuantity.Text)

            Dim updateQuery As String = "Update tbl_CarStockDetails Set Brand_Model = '" & brand_Model & "', Mfg_Year = '" & mfgYear & "', Quantity = " & quantity & " WHERE Sr_No =" & srNo & ""
            ExecuteQuery(updateQuery)
            LoadGridData()
            clearControlTextBox()
            RadMessageBox.Show("Record updated successfully ", "Success", MessageBoxButtons.OK, RadMessageIcon.Info)
        Catch ex As Exception
            RadMessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Try
            srNo = Convert.ToInt32(txtSr_No.Text)
            Dim deleteQuery As String = "delete from tbl_CarStockDetails Where Sr_No = " & srNo
            ExecuteQuery(deleteQuery)
            LoadGridData()
            RadMessageBox.Show("Record deleted successfully ", "Success", MessageBoxButtons.OK, RadMessageIcon.Info)
        Catch ex As Exception
            RadMessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        clearControlTextBox()
        formControlModes(CommonMethods.SaveMode)
    End Sub

    Public Sub ExecuteQuery(query As String)
        Try
            Dim command As New SqlCommand(query, connection)
            connection.Open()
            command.ExecuteNonQuery()
            connection.Close()
        Catch ex As Exception
            RadMessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Function fnValidate() As Boolean
        Try
            If txtSr_No.Text = "" Then
                RadMessageBox.Show("Serial number cannot be empty", "Serial number required", MessageBoxButtons.OK, RadMessageIcon.Exclamation)
                Return False
                Exit Function
            ElseIf txtBrand_Model.Text = "" Then
                RadMessageBox.Show("Brand/Model cannot be empty", "Brand/Model required", MessageBoxButtons.OK, RadMessageIcon.Exclamation)
                Return False
                Exit Function
            ElseIf txtQuantity.Text = "" Then
                RadMessageBox.Show("Quantity cannot be empty", "Quantity required", MessageBoxButtons.OK, RadMessageIcon.Exclamation)
                Return False
                Exit Function
            Else
                Return True
            End If

        Catch ex As Exception
            RadMessageBox.Show(ex.Message)
        End Try
    End Function

    Public Sub LoadGridData()
        Try
            Dim query As String = "Select * from tbl_CarStockDetails"
            Dim command As New SqlCommand(query, connection)
            Dim sda As New SqlDataAdapter(command)
            Dim dt As New DataTable
            sda.Fill(dt)
            rgvCarStocks.DataSource = dt

            'If dt.Rows.Count = 0 Then
            rgvCarStocks.Columns("Sr_No").HeaderText = "Serial Number"
            rgvCarStocks.Columns("Brand_Model").HeaderText = "Brand/Model"
            rgvCarStocks.Columns("Mfg_Year").HeaderText = "Manufactured Year"
            rgvCarStocks.Columns("Quantity").HeaderText = "Quantity"
            rgvCarStocks.BestFitColumns()
            rgvCarStocks.AutoSizeColumnsMode = GridViewAutoSizeColumnsMode.Fill
            rgvCarStocks.AllowAddNewRow = False

            For Each singleCol In rgvCarStocks.Columns
                singleCol.TextAlignment = ContentAlignment.MiddleCenter
            Next
            'End If
        Catch ex As Exception
            RadMessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub clearControlTextBox()
        rgvCarStocks.ClearSelection()
        txtSr_No.Enabled = True
        txtSr_No.Text = String.Empty
        txtBrand_Model.Text = String.Empty
        txtMfg_Year.Text = Now.Year
        txtQuantity.Text = String.Empty
    End Sub

    Private Sub formControlModes(ByVal mode As String)
        Select Case mode
            Case CommonMethods.ClearMode
                btnSave.Enabled = True
                btnUpdate.Enabled = False
                btnDelete.Enabled = False
            Case CommonMethods.SaveMode
                btnSave.Enabled = True
                btnUpdate.Enabled = False
                btnDelete.Enabled = False
            Case CommonMethods.UpdateMode
                btnSave.Enabled = False
                btnUpdate.Enabled = True
                btnDelete.Enabled = True
        End Select
    End Sub

    Private Function checkAlreadyExist() As Boolean
        connection.Open()
        Dim cmd0 As New SqlCommand("Select Sr_No from tbl_CarStockDetails where Sr_No = @SrNo", connection)
        cmd0.Parameters.AddWithValue("@SrNo", txtSr_No.Text)

        Dim reader0 As SqlDataReader = cmd0.ExecuteReader()

        If (reader0.HasRows) Then
            connection.Close()
            Return True
        Else
            connection.Close()
            Return False
        End If
    End Function

    Private Sub rgvCarStocks_SelectionChanged(sender As Object, e As EventArgs) Handles rgvCarStocks.SelectionChanged
        Try
            txtSr_No.Text = rgvCarStocks.MasterView.CurrentRow.Cells("Sr_No").Value
            txtBrand_Model.Text = rgvCarStocks.MasterView.CurrentRow.Cells("Brand_Model").Value
            txtMfg_Year.Text = rgvCarStocks.MasterView.CurrentRow.Cells("Mfg_Year").Value
            txtQuantity.Text = rgvCarStocks.MasterView.CurrentRow.Cells("Quantity").Value

            formControlModes(CommonMethods.UpdateMode)
            txtSr_No.Enabled = False
        Catch ex As Exception
            RadMessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub txtSr_No_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtSr_No.KeyPress
        If (Not Char.IsControl(e.KeyChar) _
                     AndAlso (Not Char.IsDigit(e.KeyChar) _
                     AndAlso (e.KeyChar <> Microsoft.VisualBasic.ChrW(46)))) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtQuantity_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtQuantity.KeyPress
        If (Not Char.IsControl(e.KeyChar) _
                     AndAlso (Not Char.IsDigit(e.KeyChar) _
                     AndAlso (e.KeyChar <> Microsoft.VisualBasic.ChrW(46)))) Then
            e.Handled = True
        End If
    End Sub
End Class
