﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmCarStock
    Inherits Telerik.WinControls.UI.RadForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnSave = New Telerik.WinControls.UI.RadButton()
        Me.lblQuantity = New Telerik.WinControls.UI.RadLabel()
        Me.txtQuantity = New Telerik.WinControls.UI.RadTextBox()
        Me.lblMfg_Year = New Telerik.WinControls.UI.RadLabel()
        Me.lblSr_No = New Telerik.WinControls.UI.RadLabel()
        Me.lblBrand_Model = New Telerik.WinControls.UI.RadLabel()
        Me.txtSr_No = New Telerik.WinControls.UI.RadTextBox()
        Me.txtBrand_Model = New Telerik.WinControls.UI.RadTextBox()
        Me.pnl1 = New System.Windows.Forms.Panel()
        Me.pnl2 = New System.Windows.Forms.Panel()
        Me.btnUpdate = New Telerik.WinControls.UI.RadButton()
        Me.btnClear = New Telerik.WinControls.UI.RadButton()
        Me.btnDelete = New Telerik.WinControls.UI.RadButton()
        Me.lblIntermix = New Telerik.WinControls.UI.RadLabel()
        Me.pnlOuter = New System.Windows.Forms.Panel()
        Me.rgvCarStocks = New Telerik.WinControls.UI.RadGridView()
        Me.plnMain = New Telerik.WinControls.UI.RadPanel()
        Me.txtMfg_Year = New Telerik.WinControls.UI.RadDateTimePicker()
        CType(Me.btnSave, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblQuantity, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtQuantity, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblMfg_Year, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblSr_No, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblBrand_Model, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSr_No, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtBrand_Model, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnl1.SuspendLayout()
        Me.pnl2.SuspendLayout()
        CType(Me.btnUpdate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnClear, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnDelete, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblIntermix, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlOuter.SuspendLayout()
        CType(Me.rgvCarStocks, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.rgvCarStocks.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.plnMain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.plnMain.SuspendLayout()
        CType(Me.txtMfg_Year, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnSave
        '
        Me.btnSave.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.Location = New System.Drawing.Point(97, 11)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(79, 24)
        Me.btnSave.TabIndex = 0
        Me.btnSave.Text = "Add"
        '
        'lblQuantity
        '
        Me.lblQuantity.Font = New System.Drawing.Font("Calibri", 12.0!)
        Me.lblQuantity.ForeColor = System.Drawing.Color.Black
        Me.lblQuantity.Location = New System.Drawing.Point(149, 154)
        Me.lblQuantity.Name = "lblQuantity"
        Me.lblQuantity.Size = New System.Drawing.Size(66, 24)
        Me.lblQuantity.TabIndex = 35
        Me.lblQuantity.Text = "Quantity"
        '
        'txtQuantity
        '
        Me.txtQuantity.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtQuantity.Location = New System.Drawing.Point(243, 154)
        Me.txtQuantity.MaxLength = 10
        Me.txtQuantity.Name = "txtQuantity"
        Me.txtQuantity.Size = New System.Drawing.Size(102, 24)
        Me.txtQuantity.TabIndex = 3
        Me.txtQuantity.TabStop = False
        Me.txtQuantity.Text = "0"
        '
        'lblMfg_Year
        '
        Me.lblMfg_Year.Font = New System.Drawing.Font("Calibri", 12.0!)
        Me.lblMfg_Year.ForeColor = System.Drawing.Color.Black
        Me.lblMfg_Year.Location = New System.Drawing.Point(78, 108)
        Me.lblMfg_Year.Name = "lblMfg_Year"
        Me.lblMfg_Year.Size = New System.Drawing.Size(137, 24)
        Me.lblMfg_Year.TabIndex = 33
        Me.lblMfg_Year.Text = "Manufactured Year"
        '
        'lblSr_No
        '
        Me.lblSr_No.Font = New System.Drawing.Font("Calibri", 12.0!)
        Me.lblSr_No.ForeColor = System.Drawing.Color.Red
        Me.lblSr_No.Location = New System.Drawing.Point(111, 16)
        Me.lblSr_No.Name = "lblSr_No"
        Me.lblSr_No.Size = New System.Drawing.Size(104, 24)
        Me.lblSr_No.TabIndex = 15
        Me.lblSr_No.Text = "Serial Number"
        '
        'lblBrand_Model
        '
        Me.lblBrand_Model.Font = New System.Drawing.Font("Calibri", 12.0!)
        Me.lblBrand_Model.Location = New System.Drawing.Point(117, 62)
        Me.lblBrand_Model.Name = "lblBrand_Model"
        Me.lblBrand_Model.Size = New System.Drawing.Size(98, 24)
        Me.lblBrand_Model.TabIndex = 31
        Me.lblBrand_Model.Text = "Brand/Model"
        '
        'txtSr_No
        '
        Me.txtSr_No.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSr_No.Location = New System.Drawing.Point(243, 16)
        Me.txtSr_No.MaxLength = 50
        Me.txtSr_No.Name = "txtSr_No"
        Me.txtSr_No.Size = New System.Drawing.Size(193, 24)
        Me.txtSr_No.TabIndex = 0
        Me.txtSr_No.TabStop = False
        '
        'txtBrand_Model
        '
        Me.txtBrand_Model.AutoSize = False
        Me.txtBrand_Model.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBrand_Model.Location = New System.Drawing.Point(243, 62)
        Me.txtBrand_Model.MaxLength = 250
        Me.txtBrand_Model.Multiline = True
        Me.txtBrand_Model.Name = "txtBrand_Model"
        Me.txtBrand_Model.Size = New System.Drawing.Size(193, 24)
        Me.txtBrand_Model.TabIndex = 1
        Me.txtBrand_Model.TabStop = False
        '
        'pnl1
        '
        Me.pnl1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnl1.Controls.Add(Me.txtMfg_Year)
        Me.pnl1.Controls.Add(Me.lblQuantity)
        Me.pnl1.Controls.Add(Me.txtQuantity)
        Me.pnl1.Controls.Add(Me.lblMfg_Year)
        Me.pnl1.Controls.Add(Me.lblSr_No)
        Me.pnl1.Controls.Add(Me.lblBrand_Model)
        Me.pnl1.Controls.Add(Me.txtSr_No)
        Me.pnl1.Controls.Add(Me.txtBrand_Model)
        Me.pnl1.Location = New System.Drawing.Point(9, 8)
        Me.pnl1.Name = "pnl1"
        Me.pnl1.Size = New System.Drawing.Size(588, 197)
        Me.pnl1.TabIndex = 32
        '
        'pnl2
        '
        Me.pnl2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnl2.Controls.Add(Me.btnSave)
        Me.pnl2.Controls.Add(Me.btnUpdate)
        Me.pnl2.Controls.Add(Me.btnClear)
        Me.pnl2.Controls.Add(Me.btnDelete)
        Me.pnl2.Location = New System.Drawing.Point(9, 213)
        Me.pnl2.Name = "pnl2"
        Me.pnl2.Size = New System.Drawing.Size(588, 45)
        Me.pnl2.TabIndex = 33
        '
        'btnUpdate
        '
        Me.btnUpdate.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdate.Location = New System.Drawing.Point(200, 11)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(79, 24)
        Me.btnUpdate.TabIndex = 1
        Me.btnUpdate.Text = "Update"
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(402, 11)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(79, 24)
        Me.btnClear.TabIndex = 3
        Me.btnClear.Text = "Clear"
        '
        'btnDelete
        '
        Me.btnDelete.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.Location = New System.Drawing.Point(303, 11)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(79, 24)
        Me.btnDelete.TabIndex = 2
        Me.btnDelete.Text = "Delete"
        '
        'lblIntermix
        '
        Me.lblIntermix.Font = New System.Drawing.Font("Calibri", 18.0!)
        Me.lblIntermix.ForeColor = System.Drawing.Color.Black
        Me.lblIntermix.Location = New System.Drawing.Point(229, 12)
        Me.lblIntermix.Name = "lblIntermix"
        Me.lblIntermix.Size = New System.Drawing.Size(178, 34)
        Me.lblIntermix.TabIndex = 29
        Me.lblIntermix.Text = "Car Stock Details"
        '
        'pnlOuter
        '
        Me.pnlOuter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlOuter.Controls.Add(Me.rgvCarStocks)
        Me.pnlOuter.Controls.Add(Me.pnl1)
        Me.pnlOuter.Controls.Add(Me.pnl2)
        Me.pnlOuter.Location = New System.Drawing.Point(8, 54)
        Me.pnlOuter.Name = "pnlOuter"
        Me.pnlOuter.Size = New System.Drawing.Size(607, 473)
        Me.pnlOuter.TabIndex = 34
        '
        'rgvCarStocks
        '
        Me.rgvCarStocks.Location = New System.Drawing.Point(9, 264)
        '
        'rgvCarStocks
        '
        Me.rgvCarStocks.MasterTemplate.AllowAddNewRow = False
        Me.rgvCarStocks.MasterTemplate.AllowDeleteRow = False
        Me.rgvCarStocks.MasterTemplate.AllowEditRow = False
        Me.rgvCarStocks.MasterTemplate.EnableFiltering = True
        Me.rgvCarStocks.MasterTemplate.EnableGrouping = False
        Me.rgvCarStocks.Name = "rgvCarStocks"
        Me.rgvCarStocks.ReadOnly = True
        Me.rgvCarStocks.Size = New System.Drawing.Size(588, 204)
        Me.rgvCarStocks.TabIndex = 0
        Me.rgvCarStocks.Text = "RadGridView1"
        '
        'plnMain
        '
        Me.plnMain.BackColor = System.Drawing.Color.White
        Me.plnMain.Controls.Add(Me.pnlOuter)
        Me.plnMain.Controls.Add(Me.lblIntermix)
        Me.plnMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.plnMain.Location = New System.Drawing.Point(0, 0)
        Me.plnMain.Name = "plnMain"
        Me.plnMain.Size = New System.Drawing.Size(624, 535)
        Me.plnMain.TabIndex = 19
        '
        'txtMfg_Year
        '
        Me.txtMfg_Year.CustomFormat = "yyyy"
        Me.txtMfg_Year.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMfg_Year.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.txtMfg_Year.Location = New System.Drawing.Point(243, 111)
        Me.txtMfg_Year.MaxDate = New Date(2022, 3, 14, 0, 30, 54, 0)
        Me.txtMfg_Year.MinDate = New Date(1990, 3, 9, 0, 0, 0, 0)
        Me.txtMfg_Year.Name = "txtMfg_Year"
        Me.txtMfg_Year.NullDate = New Date(2023, 2, 1, 0, 0, 0, 0)
        Me.txtMfg_Year.ShowUpDown = True
        Me.txtMfg_Year.Size = New System.Drawing.Size(193, 24)
        Me.txtMfg_Year.TabIndex = 2
        Me.txtMfg_Year.TabStop = False
        Me.txtMfg_Year.Text = "2022"
        Me.txtMfg_Year.Value = New Date(1990, 3, 9, 0, 0, 0, 0)
        '
        'FrmCarStock
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(624, 535)
        Me.Controls.Add(Me.plnMain)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmCarStock"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Car Stocks"
        CType(Me.btnSave, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblQuantity, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtQuantity, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblMfg_Year, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblSr_No, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblBrand_Model, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSr_No, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtBrand_Model, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnl1.ResumeLayout(False)
        Me.pnl1.PerformLayout()
        Me.pnl2.ResumeLayout(False)
        CType(Me.btnUpdate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnClear, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnDelete, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblIntermix, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlOuter.ResumeLayout(False)
        CType(Me.rgvCarStocks.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.rgvCarStocks, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.plnMain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.plnMain.ResumeLayout(False)
        Me.plnMain.PerformLayout()
        CType(Me.txtMfg_Year, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnSave As Telerik.WinControls.UI.RadButton
    Friend WithEvents lblQuantity As Telerik.WinControls.UI.RadLabel
    Friend WithEvents txtQuantity As Telerik.WinControls.UI.RadTextBox
    Friend WithEvents lblMfg_Year As Telerik.WinControls.UI.RadLabel
    Friend WithEvents lblSr_No As Telerik.WinControls.UI.RadLabel
    Friend WithEvents lblBrand_Model As Telerik.WinControls.UI.RadLabel
    Friend WithEvents txtSr_No As Telerik.WinControls.UI.RadTextBox
    Friend WithEvents txtBrand_Model As Telerik.WinControls.UI.RadTextBox
    Friend WithEvents pnl1 As System.Windows.Forms.Panel
    Friend WithEvents pnl2 As System.Windows.Forms.Panel
    Friend WithEvents btnUpdate As Telerik.WinControls.UI.RadButton
    Friend WithEvents btnClear As Telerik.WinControls.UI.RadButton
    Friend WithEvents btnDelete As Telerik.WinControls.UI.RadButton
    Friend WithEvents lblIntermix As Telerik.WinControls.UI.RadLabel
    Friend WithEvents pnlOuter As System.Windows.Forms.Panel
    Friend WithEvents plnMain As Telerik.WinControls.UI.RadPanel
    Friend WithEvents rgvCarStocks As Telerik.WinControls.UI.RadGridView
    Friend WithEvents txtMfg_Year As Telerik.WinControls.UI.RadDateTimePicker
End Class

