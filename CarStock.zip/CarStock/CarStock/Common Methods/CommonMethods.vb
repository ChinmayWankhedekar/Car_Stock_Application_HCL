﻿Imports System.Data.SqlClient

Public Class CommonMethods

    Public Shared ClearMode As String = "Clear"
    Public Shared SaveMode As String = "Save"
    Public Shared UpdateMode As String = "Update"

End Class
